<?php
$nombre = $_POST['nombre'];
$mail = $_POST['correo'];

/*$header = 'From: ' . $mail . " \r\n";
$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
$header .= "Mime-Version: 1.0 \r\n";
$header .= "Content-Type: text/plain";*/

$mensaje = "Este mensaje fue enviado por " . $nombre . " \r\n";
$mensaje .= "Su e-mail es: " . $mail . " \r\n";
$mensaje .= "Mensaje: " . $_POST['mensaje'] . " \r\n";
$mensaje .= "Enviado el " . date('d/m/Y', time());

$paracomercial = 'jose.radadg@gmail.com';
$asunto = 'Mensaje de Landing';

if(mail($paracomercial, $asunto, $mensaje)){
        echo "Su mensaje fue enviado satisfactoriamente.

        <head><meta http-equiv=REFRESH content=0;index.html></head>";
        
}else{
        echo "Fall&ooacute; el envio del mensaje. Intente de nuevo.

        <head><meta http-equiv=REFRESH content=0;index.html></head>";
}
?>